package com.capgemini.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo3JpaResTfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
