export class Book {
    id:number;
    bookName:string;
    author:string;
    cost:number;
 
}
