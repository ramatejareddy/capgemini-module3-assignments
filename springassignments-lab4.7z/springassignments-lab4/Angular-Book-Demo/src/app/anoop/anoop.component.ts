import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anoop',
  templateUrl: './anoop.component.html',
  styleUrls: ['./anoop.component.css']
})
export class AnoopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
