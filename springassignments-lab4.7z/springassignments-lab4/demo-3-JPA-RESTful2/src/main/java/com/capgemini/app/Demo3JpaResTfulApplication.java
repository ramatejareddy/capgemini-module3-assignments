package com.capgemini.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo3JpaResTfulApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo3JpaResTfulApplication.class, args);
	}

}
